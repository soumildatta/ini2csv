from .version import __version__
from .ini2csv import process_files
from .ini2csv import process_folder